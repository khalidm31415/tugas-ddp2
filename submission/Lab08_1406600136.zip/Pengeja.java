public interface Pengeja {
    String eja(Integer angka);
}