File yang menjalankan permainannya adalah TebakBilik.java
Fitur tambahan: 
- kita dapat memilih untuk menampilkan array yang harus ditebak, untuk memastikan permainan berjalan dengan benar
- pemain tidak dikenakan pengurangan skor dan lifepoints jika format tebakan salah

Player.java berisi kelas yang dapat menyimpan state(nama, lifepoints, dan score) dari pemain
Matrix.java berisi method untuk membuat array ukuran n x n, mengacak elemen-elemen array, dan mencetaknya
Bilik.java berisi method untuk membuat bilik serta mencetaknya
Tebak.java berisi permainan utamanya
