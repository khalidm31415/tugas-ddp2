public class TebakBilik{
    public static void main(String[] args){
        Tebak.play();
    }
}