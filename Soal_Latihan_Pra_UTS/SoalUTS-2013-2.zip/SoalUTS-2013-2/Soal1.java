public class Soal1 {
	public static void main(String[] args) {
		for(int i = 0; i < 5; i++); {
			for(int j = 6; j > 0; j--)
				if(j > 3 || j-- < 2) {
					if(j > 1) System.out.print(j);
				}
				else
					System.out.println(j);
		}
	}
}