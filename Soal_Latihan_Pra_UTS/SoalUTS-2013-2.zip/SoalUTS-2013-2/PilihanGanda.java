public class PilihanGanda {
	public static void main(String[] args) {
			System.out.println("Nomor 1");
			System.out.println("3 / 2: " + (3 / 2));
			System.out.println("3 < 2: " + (3 < 2));
			System.out.println("3 * 4: " + (3 * 4));
			System.out.println("3 == 2: " + (3 == 2));
			System.out.println();

			System.out.println("Nomor 2");
			int a = 3, b = 4;
			System.out.print("output = " + 7 + 2 + " " );
			System.out.print(a + b);
			System.out.print(" " + a + b + " " + 7);
			System.out.println();

			System.out.println("Nomor 3");
			int aNumber = 3;
			if(aNumber >= 0)
				if(aNumber == 0)
					System.out.println("first string");
				else
					System.out.println("second string");
			System.out.println("third string");
			System.out.println();

			System.out.println("Nomor 4");
			int[] aa = new int[5];
			for(int i = 0; i < 5; i++) 
				aa[i] = 4 - i;
			for(int i = 0; i < 5; i++) 
				aa[i] = aa[aa[i]];
			System.out.print("{");
			for(int i = 0; i < aa.length; i++) {
				System.out.print(aa[i]);
				if(i != aa.length - 1) 
					System.out.print(",");
			}
			System.out.println("}");
			System.out.println();

			System.out.println("Nomor 5");
			double[] values = {0,2,0,2,1,1,2,1,2,1,2};
			int counter = 0;
			for(double d : values) {
				if(d - 3 / 2 == 0)
					counter++;
			}			
			System.out.println("counter = " + counter);
			System.out.println();
	}
}