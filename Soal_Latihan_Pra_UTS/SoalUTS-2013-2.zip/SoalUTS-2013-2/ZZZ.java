public class ZZZ {
	private int xyz;
	private double aaa;
	public static int lalala = 0;
	public final double XYZ = 100;

	public ZZZ() {
		this.xyz = 0;
		this.aaa = 0.0;
	}

	public ZZZ(int xyz, double aaa) {
		this.xyz = xyz;
		this.aaa = aaa;
	}

	public int getXyz() {
		return this.xyz;
	}

	public double getAaa() {
		return this.aaa;
	}

	public void setXyz(int xyz) {
		this.xyz = xyz;
	}

	public void setAaa(double aaa) {
		this.aaa = aaa;
	}

	public String toString() {
		return "Class ZZZ {xyz = " + this.xyz + ", aaa = " + this.aaa + "}";
	}

	public static void main(String[] test) {
		ZZZ a = new ZZZ();
		System.out.println(a);

		ZZZ b = new ZZZ(3, 5.0);
		System.out.println(b);
	}
}