/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran1 {
	public static void main(String[] args)
	{
		System.out.println(1 * 3 + "2" + 5 + 2 * 3); // 1
		System.out.println((char)(('D' - 'A') + '0')); // 2
		System.out.println(5.0 / 4 - 4 / 5); // 3
		System.out.println(6 % 2 * 4  > 5 || 4 % 2 * 6 < 7); //4
		System.out.println(6 % 2 * 4  > 5 && 4 % 2 * 6 < 7); //5
		System.out.println(1 == 0 && 3 / 0 == 1); //6

		char x = 'a';
		char y = 'c';

		System.out.println(++y);//7
		System.out.println(y++); //8
		System.out.println(x > y); //9
		System.out.println(x - y); //10
	}
}
