/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran10 {
	public static void main(String[] args) {
		int a = 3;
		int b = 6;

		swap(a, b);
		System.out.println(a + " " + b);
		MyInteger aa = new MyInteger(a);
		MyInteger bb = new MyInteger(b);
		swap2(aa, bb);
		System.out.println(aa + " " + bb);
	}

	public static void swap(int x, int y) {
		int temp = x;
		x = y;
		y = temp;
	}

	public static void swap2(MyInteger x, MyInteger y) {
		int temp1 = x.getValue();
		int temp2 = y.getValue();
		x = new MyInteger(temp2);
		y = new MyInteger(temp1);
	}
}

class MyInteger {
	private int value;

	public MyInteger(int i) {
		this.value = i;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String toString() {
		return "" + this.value;
	}
}
