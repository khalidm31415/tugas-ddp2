/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran5 {
	public static void findMax(int max, int a, int b) {
		max = (a > b) ? a : b;
	}

	public static void main(String[] args) {
		int a = 20;
		int b = 10;
		int terbesar = 0;

		findMax(terbesar, a, b);
		System.out.println(terbesar);
	}
}
