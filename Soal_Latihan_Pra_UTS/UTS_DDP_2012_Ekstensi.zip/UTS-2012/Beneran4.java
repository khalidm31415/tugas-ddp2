/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran4 {
	public static void main(String[] args) {
		String str1 = "DDP";
		String str2 = "2012";
		String str3 = "DDP2012";
		String str4 = str1 + str2;

		System.out.println(str3 == str4);
		System.out.println(str3.equals(str4));
	}
}
