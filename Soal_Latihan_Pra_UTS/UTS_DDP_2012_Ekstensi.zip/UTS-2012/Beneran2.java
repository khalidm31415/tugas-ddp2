/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran2 {
	public static void main(String[] yaw) {
		for(int a = 10; a < 100; a++) {
			int b = (int) (a * Math.random());
			System.out.println("Nilai: " + b);
		}

		int a = 10;
		while(a < 100) {
			int b = (int) (a * Math.random());
			System.out.println("Nilai: " + b);
			a++;
		}
	}
}
