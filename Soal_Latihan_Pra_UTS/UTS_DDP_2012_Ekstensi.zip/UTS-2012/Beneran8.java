/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran8 {
	private static String theString;
	private int someNumber;
	private char someChar = 'a';

	public void doSomething(int someNumber, Beneran8 anotherQuestion) {
		if(++someNumber > 0 || anotherQuestion.someChar++ == 'b') {
			anotherQuestion.someChar += someNumber++;
			this.theString = "IF STATEMENT";
		}
		else {
			this.someNumber++;
			anotherQuestion.theString = "ELSE STATEMENT";
		}
	}

	public static void main(String[] args) {
		Beneran8 q1 = new Beneran8();
		Beneran8 q2 = new Beneran8();
		q1.doSomething(q1.someNumber, q2);
		
		System.out.println(q1.someNumber);
		System.out.println(q2.someNumber);
		System.out.println(q1.someChar);
		System.out.println(q2.someChar);
		System.out.println(q1.theString);
		System.out.println(q2.theString);
		
		System.out.println("");
				
		q2.doSomething(-1, q1);

		System.out.println(q1.someNumber);
		System.out.println(q2.someNumber);
		System.out.println(q1.someChar);
		System.out.println(q2.someChar);
		System.out.println(q1.theString);
		System.out.println(q2.theString);
	}
}
