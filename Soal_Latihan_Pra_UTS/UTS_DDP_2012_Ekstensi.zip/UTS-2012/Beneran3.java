/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran3 {
	private String userName;
	private String password;

	/* Constructor */
	public Beneran3(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}

	 public boolean isValidPassword() {
		 int passwordLength = this.password.length();
		 boolean equalsUsername = this.password.equalsIgnoreCase(this.userName);
		 boolean minOneUppercase = false;
		 boolean minOneLowercase = false;
		 boolean minOneDigit = false;
		 for(int i = 0; i <  this.password.toCharArray().length; i++) {
			 if(Character.isUpperCase(this.password.charAt(i))) {
				 minOneUppercase = true;
			 }
			 if(Character.isLowerCase(this.password.charAt(i))) {
				 minOneLowercase = true;
			 }
			 if(Character.isDigit(this.password.charAt(i))) {
				 minOneDigit = true;
			 }
		 }
		 boolean passwordLengthOkay = passwordLength >= 8 && passwordLength <= 12;

		 return passwordLengthOkay && !equalsUsername && minOneUppercase && minOneLowercase && minOneDigit;
	 }

	public String passwordStatus() {
		if(this.isValidPassword()) {
			return "Valid";
		}
		else {
			return "Not Valid";
		}
	}

	public static void main(String[] arg) {
		Beneran3 a = new Beneran3("PSY", "PSY");
		System.out.println(a.passwordStatus());
		a = new Beneran3("PSY", "psy");
		System.out.println(a.passwordStatus());
		a = new Beneran3("PSY", "pSY1");
		System.out.println(a.passwordStatus());
		a = new Beneran3("PSY", "psypsypsy");
		System.out.println(a.passwordStatus());
		a = new Beneran3("PSY", "PSYPSYPSY");
		System.out.println(a.passwordStatus());
		a = new Beneran3("PSY", "PSYpsyPSY");
		System.out.println(a.passwordStatus());
		a = new Beneran3("PSY", "PSYpsy123");
		System.out.println(a.passwordStatus());
	}
}
