/**
 * Created by IntelliJ IDEA.
 *
 * @author Zaki Rahman <zaki@pusilkom.ui.ac.id>
 */
public class Beneran9 {
	public static void main(String[] args) {
		int n = 5;
		Beneran9 soal = new Beneran9();
		int[][] matriks = soal.isiMatriks(n);
		for(int i = 0; i < matriks.length; i++) {
			for(int j = 0; j < matriks.length; j++) {
				System.out.print(matriks[i][j] + " ");
			}
			System.out.println();
		}
	}

	public int[][] isiMatriks(int n) {
		int[][] output = new int[n][n];
		int number = 1;
		
		for(int i = 0; i < output.length; i++) {			
			if(i % 2 == 0) {
				for(int j = 0; j < output.length; j++) {
					output[i][j] = number++;
				}
			}
			else {
				for(int j = output.length - 1; j >= 0; j--) {
					output[i][j] = number++;
				}
			}
		}
		return output;
	}
}
